//
// This very simple program reads a string from the command line
// and encrypts it with the pre-defined salt.
//
// This program can be compiled with "gcc crypt.c -lcrypt".
//

#define _XOPEN_SOURCE	
#include <stdlib.h>
#include <unistd.h>		
#include <iostream>
#include <string>

using namespace std;

int main(int argc, char* argv[]) {
	
	if (argc != 1) {
		cout << "No command line arguments required" << endl;
		exit(0);
	}
	
        // Get the code for the algorithm.
	string algorithm;
        cout << "Enter the algorithm id ";
	cin >> algorithm;

        // Get the salt
	string salt;
        cout << "Enter the salt ";
	cin >> salt;

        // Get the plaintext
	string cleartext;
        cout << "Enter the password ";
	cin >> cleartext;
	
        // Get the glue it togeter.
	string salt2 = "$" + algorithm + "$" + salt + "$";
	
	// Now we call crypt.
	char* password = crypt(cleartext.c_str(),salt2.c_str());
	
	cout << "The crypted version is " << password << endl;
}
